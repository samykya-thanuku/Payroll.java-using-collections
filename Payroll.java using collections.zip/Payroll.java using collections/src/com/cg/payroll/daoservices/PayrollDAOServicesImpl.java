package com.cg.payroll.daoservices;
import java.util.HashMap;
import java.util.List;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.utility.PayrollUtility;
public class PayrollDAOServicesImpl implements PayrollDAOServices{
public static HashMap<Integer,Associate> associates = new HashMap<>();

	@Override
	public int insertAssociate(Associate associate) {
		associate.setAssociateID(PayrollUtility.ASSOCIATE_ID_COUNTER++);
		associates.put(associate.getAssociateID(),associate);
		return associate.getAssociateID();
	}

	@Override
	public boolean updateAssociate(Associate associate) {
		associates.put(associate.getAssociateID(),associate);
		return true;
	}

	@Override
	public boolean deleteAssociate(Associate associate) {
		associates.remove(associate.getAssociateID(),associate);
		return true;
	}

	@Override
	public Associate getAssociate(int associateId) {
		return associates.get(associateId);
			}

	@Override
	public List<Associate> getAssociates() {
		
		return null;
	}

	

	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	/*private static Associate[] associateList=new Associate[10];
	private static int ASSOCIATE_ID_COUNTER=110;
	private static int ASSOCIATE_IDX_COUNTER=0;
	@Override
	public int insertAssociate(Associate associate){
		if(ASSOCIATE_IDX_COUNTER>=0.7*associateList.length){
			Associate[] temp = new Associate[associateList.length+10];
			System.arraycopy(associateList, 0, temp, 0, 10);
			associateList=temp;
		}
		associate.setAssociateID(ASSOCIATE_ID_COUNTER++);
		associateList[ASSOCIATE_IDX_COUNTER++]=associate;
		return associate.getAssociateID();
	}
	@Override
	public boolean updateAssociate(Associate associate){

		for(int i=0;i<associateList.length;i++) 
			if (associateList[i]!=null && associate.getAssociateID()==associateList[i].getAssociateID()) {
				associateList[i]=associate;
				return true;
			}
		return false;
	}
	@Override
	public boolean deleteAssociate(Associate associate){
		for(int i=0;i<associateList.length;i++)
			if (associateList[i]!=null && associate.getAssociateID()==associateList[i].getAssociateID()) {
				associateList[i]=null;
				return true;
			}
		return false;
	}
	@Override
	public Associate getAssociate(int associateId){
		for(int i=0;i<associateList.length;i++) 
			if (associateList[i]!=null && associateId==associateList[i].getAssociateID()) 
				return associateList[i];
		return null;
	}
	@Override
	public Associate[] getAssociates(){	
		return associateList;
	}
	@Override
	public int updateList() {
		for(int i=0;i<associateList.length;i++) 
			if (associateList[i]==null ) 
				for(int j=i+1;j<associateList.length;j++)
					if(associateList[j]!=null) {
						associateList[i]=associateList[j];
						associateList[j]=null;
						i++;
					}		
		for(int i=0;i<associateList.length;i++)
			if(associateList[i]!=null)
				ASSOCIATE_IDX_COUNTER++;
		return ASSOCIATE_IDX_COUNTER;
	}*/
}
