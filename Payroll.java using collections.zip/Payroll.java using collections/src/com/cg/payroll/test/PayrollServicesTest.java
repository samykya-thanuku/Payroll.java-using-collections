package com.cg.payroll.test;

import static org.junit.Assert.assertEquals;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.PayrollDAOServicesImpl;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.utility.PayrollUtility;

public class PayrollServicesTest {

	private static PayrollServices payrollservices;
	@BeforeClass
	public static void setUpTestEnv(){
		payrollservices=new PayrollServicesImpl();
	
	}
	//private int associateId;
	@Before 
	public  void setUpMockData(){
		PayrollUtility.ASSOCIATE_ID_COUNTER=111;
		Associate associate1=new Associate(PayrollUtility.ASSOCIATE_ID_COUNTER++, 12000, "mani", "reddy", "eee", "analyst", "FYT566", "mani.com", new Salary(230000, 10000, 19000), new BankDetails(1234, "xyz", "FYTGH256365"));
		Associate associate2=new Associate(PayrollUtility.ASSOCIATE_ID_COUNTER++, 13000, "sam", "pichi", "ece", "analyst", "FYT56667", "sam.com", new Salary(240000, 10404, 23000), new BankDetails(12345, "asd", "FYTGH223265"));
		Associate associate3=new Associate(PayrollUtility.ASSOCIATE_ID_COUNTER++, 14000, "anu", "buchi", "eie", "analyst", "FYT56643", "anu.com", new Salary(250000, 1000, 149000), new BankDetails(12346, "qwe", "HJKKTGH256365"));

		PayrollDAOServicesImpl.associates.put(associate1.getAssociateID(), associate1);
		PayrollDAOServicesImpl.associates.put(associate2.getAssociateID(), associate2);
		PayrollDAOServicesImpl.associates.put(associate3.getAssociateID(), associate3);
		
	}
	@Test
	public void validAssociateDetails() throws  AssociateDetailsNotFoundException
{
		Associate expectedassociate=payrollservices.getAssociateDetails(112);
		Associate actualassociate=new Associate(112, 13000, "sam", "pichi", "ece", "analyst", "FYT56667", "sam.com", new Salary(240000, 10404, 23000), new BankDetails(12345, "asd", "FYTGH223265"));
		assertEquals(expectedassociate, actualassociate);
	}

	@Test(expected=AssociateDetailsNotFoundException.class)
	public void inValidAssociateDetails() throws  AssociateDetailsNotFoundException
{
		Associate expectedassociate=payrollservices.getAssociateDetails(1147);
		Associate actualassociate=new Associate(PayrollUtility.ASSOCIATE_ID_COUNTER++, 13000, "sam", "pichi", "ece", "analyst", "FYT56667", "sam.com", new Salary(240000, 10404, 23000), new BankDetails(12345, "asd", "FYTGH223265"));
		assertEquals(expectedassociate, actualassociate);
	}

@Test 
public void netsalary() throws AssociateDetailsNotFoundException
{
	Assert.assertEquals(309329.34375, payrollservices.calculateNetSalary(112), 0);

}

@Test
public void correctAssociateId() throws AssociateDetailsNotFoundException{
//Associate expectedassociate=payrollservices.getAssociateDetails(114);
//Associate actualassociate=new Associate(PayrollUtility.ASSOCIATE_ID_COUNTER++, 13000, "samtyt", "pichtgri", "ec", "analst", "FYT5667", "am.com", new Salary(24000, 0404, 3000), new BankDetails(1235, "ad", "FYTGH23265"));
assertEquals(114,PayrollUtility.ASSOCIATE_ID_COUNTER++ );
}



	@After
	public  void tearDownMockData(){
		PayrollDAOServicesImpl.associates.clear();
		//PayrollDAOServicesImpl.associates.remove(PayrollUtility.ASSOCIATE_ID_COUNTER++);
		PayrollUtility.ASSOCIATE_ID_COUNTER=111;
		
		
	}
	
	@AfterClass
	public static void tearDownTestEnv(){
		payrollservices=null;
	
	}
}